import { useState, useEffect } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X, Trash2, MessageCircle, User, Check, ArrowRight } from 'lucide-react';
import { TbCurrencyNaira } from 'react-icons/tb';
import { toast } from 'sonner';
import { useSelector, useDispatch } from 'react-redux';
import Button from './button';
import { Textarea } from './textarea';
import { Input } from './input';
import { Checkbox } from './checkbox';
import { guestFormSchema } from '../../lib/zodSchemas';
import { supabase } from '../../supabaseClient';
import { buildWhatsAppUrl, WHATSAPP_NUMBER } from '../../lib/whatsappConfig';
import { selectCurrentUser, selectUserProfile, selectIsAuthenticated } from '../../features/authSlice';
import LoginForm from "../../Layout/ProductPage/LoginForm";
import { SignupForm } from "../../Layout/ProductPage/signup-form";


const guestBenefits = [
  'Quick Request',
  'No Sign-Up Required',
  'Instant WhatsApp Contact',
];

const accountBenefits = [
  'Save Favorites',
  'Track Request History',
  'Faster Future Requests',
];

export default function SelectedRequestModal({ open, onClose, selectedProducts = [], onRemoveItem, onConfirm }) {
     const dispatch = useDispatch();
  const user = useSelector(selectCurrentUser);
  const profile = useSelector(selectUserProfile);
  const isAuthenticated = useSelector(selectIsAuthenticated);
  const userId = isAuthenticated && (user?.id || profile?.id) ? (user?.id || profile?.id) : null;

  const [message, setMessage] = useState('');
  const [step, setStep] = useState('summary');
  const [guestForm, setGuestForm] = useState({ fullName: '', contact: '', termsAccepted: false });
  const [formErrors, setFormErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedProducts, setSubmittedProducts] = useState([]);

  useEffect(() => {
    if (!open) {
      setMessage('');
      setGuestForm({ fullName: '', contact: '', termsAccepted: false });
      setFormErrors({});
      setIsSubmitting(false);
      setSubmittedProducts([]);
      setStep('summary');
    }
  }, [open]);

  useEffect(() => {
    if (open && (user || profile)) {
      const autofillName =
        profile?.full_name ||
        user?.user_metadata?.full_name ||
        user?.user_metadata?.name ||
        '';
      const autofillContact =
        profile?.phone_number ||
        profile?.phone ||
        user?.user_metadata?.phone_number ||
        user?.user_metadata?.phone ||
        user?.phone ||
        '';

      setGuestForm((current) => ({
        ...current,
        fullName: current.fullName || autofillName,
        contact: current.contact || autofillContact,
      }));
    }
  }, [open, user, profile]);

  const total = selectedProducts.reduce((s, p) => s + Number(p.ProductPrice || p.price || 0), 0);
  const hasSelection = Array.isArray(selectedProducts) && selectedProducts.length > 0;

  const handleGuestContinue = (event) => {
    event?.stopPropagation?.();
    setStep('guestForm');
  };

  const handleLoginContinue = (event) => {
    event?.stopPropagation?.();
    setStep('login');
  };

  const handleGuestSubmit = async (event) => {
    event.preventDefault();

    const parsed = guestFormSchema.safeParse({
      fullName: guestForm.fullName,
      contact: guestForm.contact,
      message,
      termsAccepted: guestForm.termsAccepted,
    });

    if (!parsed.success) {
      const nextErrors = {};
      parsed.error.issues.forEach((issue) => {
        const field = issue.path[0] ?? 'form';
        nextErrors[field] = issue.message;
      });
      setFormErrors(nextErrors);
      return;
    }

    setIsSubmitting(true);

    try {
      const snapshot = [...selectedProducts];
      const payload = snapshot.map((product) => ({
        user_id: userId || null,
        userName: parsed.data.fullName || null,
        UserPhoneNumber: parsed.data.contact || null,
        ItemDetails: parsed.data.message || message || null,
        ItemCategory: product?.Category ?? null,
        ItemImage: product?.imageUrl ?? product?.ImageUrl ?? null,
        ItemPrice: Number(product?.ProductPrice ?? product?.price ?? 0),
        ItemName: product?.ProductName ?? product?.name ?? 'Selected item',
        ReqType: 'Product Request',
        status: 'pending',
      }));

      const { error } = await supabase.from('All_Requests').insert(payload);

      if (error) throw error;

      setSubmittedProducts(snapshot);

      onConfirm({
        mode: isAuthenticated ? 'user' : 'guest',
        message: parsed.data.message || message,
        contact: parsed.data.contact,
        fullName: parsed.data.fullName,
        selectedProducts: snapshot,
      });

      setGuestForm({ fullName: '', contact: '', termsAccepted: false });
      setFormErrors({});
      setStep('success');
    } catch (error) {
      toast.error(error?.message || 'Unable to submit your request right now.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleContinueWhatsApp = () => {
    const productNames = (submittedProducts.length ? submittedProducts : selectedProducts)
      .map((product) => product.ProductName || product.name)
      .filter(Boolean)
      .join(', ');

    const messageText = `Hello Universal Market, I have submitted a wishlist request for: ${productNames || 'selected items'}. Please confirm availability and next steps.`;
    const url = buildWhatsAppUrl(WHATSAPP_NUMBER, messageText);

    if (!url) {
      toast.error('WhatsApp number is not configured yet.');
      return;
    }

    window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div className="fixed inset-0 z-50 flex items-end justify-center md:items-center" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="absolute inset-0 bg-black/50" onClick={onClose} />

          <motion.div
            role="dialog"
            aria-modal="true"
            className="relative w-full max-w-2xl rounded-t-2xl bg-white p-4 shadow-2xl md:rounded-3xl md:p-6"
            initial={{ y: 80 }}
            animate={{ y: 0 }}
            exit={{ y: 40 }}
            onClick={(event) => event.stopPropagation()}
          >
            {step === 'summary' ? (
              <>
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-[#01241a]">Request summary</h3>
                  <button onClick={onClose} aria-label="Close" className="rounded p-1 text-gray-600 hover:bg-gray-100">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="mt-4 max-h-64 space-y-3 overflow-y-auto">
                  {selectedProducts.map((p) => (
                    <div key={p.id} className="flex items-center gap-3 rounded-lg border border-gray-100 p-2">
                      <img src={p.imageUrl || p.ImageUrl} alt={p.ProductName || p.name} className="h-12 w-12 shrink-0 rounded-md object-cover" />
                      <div className="min-w-0 flex-1">
                        <div className="truncate font-medium text-[#01241a]">{p.ProductName || p.name}</div>
                        <div className="mt-1 flex items-center gap-2 text-sm text-gray-600">
                          <span className="flex items-center font-semibold text-[#01241a]"><TbCurrencyNaira />{Number(p.ProductPrice || p.price || 0).toLocaleString()}</span>
                          <span className="text-gray-300">•</span>
                          <span className="inline-flex rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-800">{p.ProductStatus || 'Good'}</span>
                        </div>
                      </div>

                      <button onClick={() => onRemoveItem(p.id)} aria-label={`Remove ${p.ProductName || p.name}`} className="rounded p-2 text-red-500 hover:bg-red-50">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>

                {/* <div className="mt-4">
                  <label className="mb-2 block text-sm font-medium text-gray-700">Optional message</label>
                  <Textarea value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Add an optional message for this request (e.g. preferred color, condition)" />
                </div> */}

                <div className="mt-4 flex items-center justify-between">
                  <div className="text-sm text-gray-600">Total: <span className="font-semibold text-[#01241a]">₦{Number(total).toLocaleString()}</span></div>
                  <div className="flex items-center gap-3">
                    <Button type="button" variant="outline" onClick={onClose} className="h-10 border-gray-200 text-gray-600">Cancel</Button>
                    <Button
                      type="button"
                      onClick={() => setStep(isAuthenticated ? 'guestForm' : 'authChoice')}
                      disabled={!hasSelection}
                      className={`${hasSelection ? 'h-10 bg-[#064e3b] text-white' : 'h-10 bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                    >
                      Continue
                    </Button>
                  </div>
                </div>
              </>
            ) : step === 'success' ? (
              <div className="space-y-6 p-2 text-center">
                <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-700">
                  <Check className="h-8 w-8" strokeWidth={3} />
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-[#01241a]">Request submitted successfully</h3>
                  <p className="mt-3 text-sm leading-6 text-gray-600">
                    We've received your request. Continue on WhatsApp to discuss availability and purchase.
                  </p>
                </div>

                <div className="space-y-3">
                  <Button
                    type="button"
                    onClick={handleContinueWhatsApp}
                    className="h-11 w-full bg-[#25D366] text-white hover:bg-[#1fb75d]"
                  >
                    Continue on WhatsApp
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    onClick={onClose}
                    className="h-11 w-full border-gray-200 text-gray-700"
                  >
                    Back to wishlist
                  </Button>
                </div>
              </div>
            ) : step === 'guestForm' ? (
              <form onSubmit={handleGuestSubmit} className="space-y-4 p-1">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-[#01241a]">
                      {isAuthenticated ? 'Request details' : 'Guest request details'}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {isAuthenticated ? 'Confirm your details and send your request.' : 'Complete the form below to send your request.'}
                    </p>
                  </div>
                  <button type="button" onClick={onClose} aria-label="Close" className="rounded p-1 text-gray-600 hover:bg-gray-100">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Full Name</label>
                  <Input
                    value={guestForm.fullName}
                    onChange={(event) => setGuestForm((current) => ({ ...current, fullName: event.target.value }))}
                    placeholder="e.g. John Doe"
                    className="bg-white text-[14px]"
                  />
                  {formErrors.fullName && <p className="text-sm text-red-600 text-[14px]">{formErrors.fullName}</p>}
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">WhatsApp or phone number</label>
                  <Input
                    value={guestForm.contact}
                    onChange={(event) => setGuestForm((current) => ({ ...current, contact: event.target.value }))}
                    placeholder="e.g. 234 800 000 0000"
                    className="bg-white text-[14px]"
                  />
                  {formErrors.contact && <p className="text-sm text-red-600 text-[14px]">{formErrors.contact}</p>}
                </div>

                <div className="space-y-2">
                  <label className="block text-sm font-medium text-gray-700">Optional message</label>
                  <Textarea
                    value={message}
                    onChange={(event) => setMessage(event.target.value)}
                    placeholder="Tell us about the item you want, condition, or preferred delivery details."
                    className="min-h-[100px] bg-white text-[14px]"
                  />
                </div>

                <div className="flex items-center gap-2 rounded-lg border border-gray-200 bg-gray-50 p-3">
                  <Checkbox
                    checked={guestForm.termsAccepted}
                    onCheckedChange={(checked) => setGuestForm((current) => ({ ...current, termsAccepted: !!checked }))}
                  />
                  <label className="text-sm text-gray-700">I agree to be contacted regarding this request.</label>
                </div>
                {formErrors.termsAccepted && <p className="text-sm text-red-600 text-[14px]">{formErrors.termsAccepted}</p>}

                <div className="flex items-center justify-between gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => setStep(isAuthenticated ? 'summary' : 'authChoice')} className="h-10 border-gray-200 text-gray-600">Back</Button>
                  <Button type="submit" disabled={isSubmitting} className="h-10 bg-[#064e3b] text-white">
                    {isSubmitting ? 'Submitting...' : 'Submit request'}
                  </Button>
                </div>
              </form>
            ) : (step === "login") ? (
              <LoginForm
                showBackButton={true}
                onBack={() => setStep('summary')}
                onClose={onClose}
                onSuccess={() => setStep('guestForm')}
                onSwitchToSignup={() => setStep('signup')}
              />
            ) : (step === "signup") ? (
              <SignupForm showBackButton={true} onClose={onClose} onSuccess={() => setStep('guestForm')} onSwitchToLogin={() => setStep('login')} onBack={() => setStep('summary')}/>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-lg font-bold text-[#01241a]">Choose how to continue</p>
                    <p className="text-sm text-gray-500">Sign in or continue without an account.</p>
                  </div>
                  <button onClick={onClose} aria-label="Close" className="rounded p-1 text-gray-600 hover:bg-gray-100">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-2 gap-4 mt-1 p-4">
                  <button
                    type="button"
                    onClick={handleGuestContinue}
                    className="group relative w-full text-left rounded-2xl border-2 border-emerald-700 bg-emerald-50 p-3 sm:p-5 shadow-sm hover:shadow-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:ring-offset-2"
                  >
                    <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-emerald-700 flex items-center justify-center mb-3 mt-1 shadow-sm group-hover:scale-105 transition-transform duration-200">
                      <MessageCircle className="w-5 h-5 text-white" />
                    </div>

                    <h4 className="text-sm sm:text-base font-bold text-gray-900 mb-1">Continue as Guest</h4>
                    <p className="text-xs sm:text-sm text-gray-500 mb-4 leading-relaxed">No account required. Submit your request and continue on WhatsApp.</p>

                    <ul className="space-y-1.5 mb-5 hidden sm:block">
                      {guestBenefits.map((b) => (
                        <li key={b} className="flex items-center gap-2 text-sm text-emerald-800 font-medium">
                          <span className="w-4 h-4 rounded-full bg-emerald-700/20 flex items-center justify-center shrink-0">
                            <Check className="w-2.5 h-2.5 text-emerald-700 stroke-3" />
                          </span>
                          {b}
                        </li>
                      ))}
                    </ul>

                    <div className="flex items-center justify-between w-full bg-emerald-700 group-hover:bg-emerald-800 text-white text-sm font-semibold px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl transition-colors duration-150">
                      <span>Continue as Guest</span>
                      <ArrowRight className="w-4 h-4" />
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={handleLoginContinue}
                    className="group w-full text-left rounded-2xl border-2 border-gray-200 bg-white p-3 sm:p-5 shadow-sm hover:shadow-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-gray-300 focus:ring-offset-2"
                  >
                    <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-gray-100 flex items-center justify-center mb-3 mt-1 group-hover:bg-gray-200 transition-colors duration-200">
                      <User className="w-5 h-5 text-gray-600" />
                    </div>

                    <h4 className="text-sm sm:text-base font-bold text-gray-900 mb-1">Login or Register</h4>
                    <p className="text-xs sm:text-sm text-gray-500 mb-4 leading-relaxed">Save products, track requests, and enjoy a faster experience next time.</p>

                    <ul className="space-y-1.5 mb-5 hidden sm:block">
                      {accountBenefits.map((b) => (
                        <li key={b} className="flex items-center gap-2 text-sm text-gray-600 font-medium">
                          <span className="w-4 h-4 rounded-full bg-gray-100 flex items-center justify-center shrink-0">
                            <Check className="w-2.5 h-2.5 text-gray-500 stroke-3" />
                          </span>
                          {b}
                        </li>
                      ))}
                    </ul>

                    <div className="flex items-center justify-between w-full border-2 border-gray-200 text-gray-700 text-sm font-semibold px-3 py-2 sm:px-4 sm:py-2.5 rounded-xl group-hover:border-gray-300 group-hover:bg-gray-50 transition-colors duration-150 text-center">
                      <span>Login or Register</span>
                      <ArrowRight className="w-4 h-4 text-gray-400" />
                    </div>
                  </button>
                </div>
              </>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
