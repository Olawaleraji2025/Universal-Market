import { MdOutlineWorkspacePremium, MdOutlineVerified } from "react-icons/md";
import { TbCreditCard } from "react-icons/tb";

export const Cards = () => (
  
    <section className="p-6.25 bg-[#01241a] text-white md:py-20 px-6">
             <div className="text-center mb-6">
                <h2 className="text-[25px] md:text-3xl font-bold">Why you should Trusts Us</h2>
                <p className="text-[14px]  text-emerald-100/60">We've built our reputation on honesty and quality.</p>
              </div>
    <div className="grid md:flex flex-wrap mb-8 gap-8 text-center justify-center">
      <div className="market-info-card">
        <div className="bg-[#60e9c2] p-4 rounded-xl">
        <MdOutlineWorkspacePremium className="trust-icons"/>
        </div>
        <p>Premium Quality</p>
        <span>100% inspected and certified hardware with our signature guarantee.</span>
      </div>

      <div className="market-info-card">
        <div className="bg-[#60e9c2] p-4 rounded-xl">
          
        <MdOutlineVerified className="trust-icons" />
        </div>
        <p>Trusted Marketplace</p>
        <span>Clear product information and straightforward communication..</span>
      </div>

      <div className="market-info-card">
        <div className="bg-[#60e9c2] p-4 rounded-xl">
        <TbCreditCard className="trust-icons"/>
        </div>
        <p> Flexible Purchase</p>
        <span>Connect with us directly to confirm availability and complete your purchase.</span>
      </div>
    </div>
          </section>
    );










